package sy.basatet

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import sy.basatet.data.StallRepository
import sy.basatet.ui.App
import sy.basatet.ui.theme.BasatetTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val repository = StallRepository(applicationContext)
        repository.cleanupOrphanImages()

        setContent {
            BasatetTheme {
                App(repository)
            }
        }
    }
}

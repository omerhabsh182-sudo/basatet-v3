package sy.basatet.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import sy.basatet.data.Sale
import sy.basatet.data.StallRepository
import sy.basatet.domain.fmtMoney
import sy.basatet.domain.startOfDay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SalesScreen(repository: StallRepository) {
    val data = repository.data
    val dayStart = startOfDay()
    val todaySales = data.sales
        .filter { it.soldAt >= dayStart && !it.isVoided }
        .sortedByDescending { it.soldAt }
    var message by remember { mutableStateOf<String?>(null) }
    val timeFmt = remember { SimpleDateFormat("HH:mm", Locale.US) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("مبيعات اليوم", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        message?.let { Text(it, color = MaterialTheme.colorScheme.primary); Spacer(Modifier.height(8.dp)) }
        if (todaySales.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
                Text("لا مبيعات اليوم", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(todaySales, key = { it.id }) { sale ->
                    SaleRow(
                        sale = sale,
                        time = timeFmt.format(Date(sale.soldAt)),
                        onReturn = {
                            repository.returnSale(sale.id)
                            message = "تم الإرجاع"
                        },
                        onUndoReturn = {
                            message = repository.undoReturn(sale.id) ?: "أُلغي الإرجاع"
                        },
                    )
                }
            }
        }
    }
}

@Composable
private fun SaleRow(
    sale: Sale,
    time: String,
    onReturn: () -> Unit,
    onUndoReturn: () -> Unit,
) {
    val returned = sale.returnedAt > 0
    Card(Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(1.dp)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(sale.productName, fontWeight = FontWeight.SemiBold)
                Text(fmtMoney(sale.soldPrice), color = if (returned) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
            }
            val label = listOf(sale.size, sale.color).filter { it.isNotBlank() }.joinToString(" / ")
            Text("$time${if (label.isNotBlank()) " · $label" else ""}${if (returned) " · مرتجع" else ""}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (!returned) {
                TextButton(onClick = onReturn) { Text("إرجاع") }
            } else {
                TextButton(onClick = onUndoReturn) { Text("التراجع عن الإرجاع") }
            }
        }
    }
}

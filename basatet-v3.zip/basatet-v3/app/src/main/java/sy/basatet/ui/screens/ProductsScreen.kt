package sy.basatet.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.ViewModule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import sy.basatet.data.Product
import sy.basatet.data.StallRepository
import sy.basatet.data.Variant
import sy.basatet.data.ViewMode
import sy.basatet.domain.fmtMoney
import sy.basatet.domain.parseDigits
import sy.basatet.ui.components.ProductImage
import java.io.File

@Composable
fun ProductsScreen(repository: StallRepository) {
    val data = repository.data
    val products = data.products.filter { it.isActive }
    var showAdd by remember { mutableStateOf(false) }
    var showViewMode by remember { mutableStateOf(false) }
    val imagesDir = repository.imagesDirectory()

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }) {
                Icon(Icons.Default.Add, "إضافة")
            }
        },
        topBar = {
            TopAppBar(
                title = { Text("المخزون") },
                actions = {
                    IconButton(onClick = { showViewMode = true }) {
                        Icon(Icons.Default.ViewModule, "طريقة العرض")
                    }
                },
            )
        },
    ) { padding ->
        if (products.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("لا يوجد منتجات\nاضغط + للإضافة", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            val mode = data.settings.viewMode
            when (mode) {
                ViewMode.GRID2, ViewMode.GRID3 -> {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(mode.columns),
                        contentPadding = PaddingValues(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(padding),
                    ) {
                        items(products, key = { it.id }) { ProductCard(it, imagesDir, compact = true) }
                    }
                }
                else -> {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(if (mode == ViewMode.COMPACT) 4.dp else 10.dp),
                        modifier = Modifier.padding(padding),
                    ) {
                        items(products, key = { it.id }) {
                            ProductCard(it, imagesDir, compact = mode == ViewMode.COMPACT)
                        }
                    }
                }
            }
        }
    }

    if (showViewMode) {
        ModalBottomSheet(onDismissRequest = { showViewMode = false }) {
            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("طريقة العرض", style = MaterialTheme.typography.titleLarge)
                ViewMode.entries.forEach { mode ->
                    FilterChip(
                        selected = data.settings.viewMode == mode,
                        onClick = {
                            repository.updateSettings(data.settings.copy(viewMode = mode))
                            showViewMode = false
                        },
                        label = { Text(mode.label) },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }
    }

    if (showAdd) {
        AddProductSheet(
            repository = repository,
            categories = data.categories,
            onDismiss = { showAdd = false },
            onSave = { repository.addProduct(it); showAdd = false },
            onAddCategory = { name ->
                if (name.isNotBlank()) repository.setCategories(data.categories + name)
            },
        )
    }
}

@Composable
private fun ProductCard(product: Product, imagesDir: File, compact: Boolean) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(1.dp),
    ) {
        Row(
            Modifier.padding(if (compact) 10.dp else 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            ProductImage(
                imagePath = product.imagePath,
                imagesDir = imagesDir,
                size = if (compact) 48.dp else 64.dp,
            )
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(product.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(
                    "${product.category} · ${fmtMoney(product.price)} · مخزون ${product.totalStock}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (!compact && product.variants.isNotEmpty()) {
                    Text(
                        product.variants.joinToString(" · ") {
                            val label = listOf(it.size, it.color).filter { s -> s.isNotBlank() }.joinToString("/")
                            "${label.ifBlank { "—" }}:${it.stock}"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
private fun AddProductSheet(
    repository: StallRepository,
    categories: List<String>,
    onDismiss: () -> Unit,
    onSave: (Product) -> Unit,
    onAddCategory: (String) -> Unit,
) {
    val context = LocalContext.current
    var name by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(categories.firstOrNull() ?: "") }
    var cost by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var multi by remember { mutableStateOf(false) }
    var size by remember { mutableStateOf("") }
    var color by remember { mutableStateOf("") }
    var stock by remember { mutableStateOf("1") }
    var variants by remember { mutableStateOf(listOf<Variant>()) }
    var newCat by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var imagePath by remember { mutableStateOf("") }

    // Camera capture temp file
    val cameraFile = remember {
        File(context.cacheDir, "capture_${System.currentTimeMillis()}.jpg")
    }
    val cameraUri = remember {
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", cameraFile)
    }

    val galleryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            repository.saveProductImage(uri)?.let { imagePath = it }
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success ->
        if (success && cameraFile.exists()) {
            val uri = Uri.fromFile(cameraFile)
            // Copy into images dir via content... File URI may need direct copy
            try {
                val name = "${java.util.UUID.randomUUID()}.jpg"
                val dest = File(repository.imagesDirectory(), name)
                cameraFile.copyTo(dest, overwrite = true)
                imagePath = name
                cameraFile.delete()
            } catch (_: Exception) {
            }
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) cameraLauncher.launch(cameraUri)
    }

    fun launchCamera() {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) cameraLauncher.launch(cameraUri)
        else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier.padding(horizontal = 24.dp).padding(bottom = 32.dp).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("إضافة منتج", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

            // صورة
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                ProductImage(
                    imagePath = imagePath,
                    imagesDir = repository.imagesDirectory(),
                    size = 72.dp,
                )
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedButton(onClick = { galleryLauncher.launch("image/*") }) {
                        Icon(Icons.Default.PhotoLibrary, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("المعرض")
                    }
                    OutlinedButton(onClick = { launchCamera() }) {
                        Icon(Icons.Default.CameraAlt, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("الكاميرا")
                    }
                }
            }

            OutlinedTextField(name, { name = it }, label = { Text("الاسم") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Text("القسم", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                categories.forEach { cat ->
                    FilterChip(selected = category == cat, onClick = { category = cat }, label = { Text(cat) })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(newCat, { newCat = it }, label = { Text("قسم جديد") }, singleLine = true, modifier = Modifier.weight(1f))
                TextButton(onClick = {
                    if (newCat.isNotBlank()) {
                        onAddCategory(newCat.trim())
                        category = newCat.trim()
                        newCat = ""
                    }
                }) { Text("إضافة") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(cost, { cost = it }, label = { Text("التكلفة") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                OutlinedTextField(price, { price = it }, label = { Text("سعر البيع") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("عدة مقاسات")
                Spacer(Modifier.weight(1f))
                Switch(checked = multi, onCheckedChange = { multi = it })
            }
            if (multi) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(size, { size = it }, label = { Text("مقاس") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(color, { color = it }, label = { Text("لون") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(stock, { stock = it }, label = { Text("كمية") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(0.8f))
                }
                TextButton(onClick = {
                    variants = variants + Variant(size = size.trim(), color = color.trim(), stock = parseDigits(stock).toInt().coerceAtLeast(0))
                    size = ""; color = ""; stock = "1"
                }) { Text("إضافة مقاس") }
                if (variants.isNotEmpty()) {
                    Text(variants.joinToString { "${it.size}/${it.color}:${it.stock}" })
                }
            } else {
                OutlinedTextField(stock, { stock = it }, label = { Text("الكمية") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
            }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Button(
                onClick = {
                    if (name.isBlank()) { error = "أدخل الاسم"; return@Button }
                    val priceL = parseDigits(price)
                    if (priceL <= 0) { error = "أدخل سعر البيع"; return@Button }
                    val vars = if (multi) {
                        if (variants.isEmpty()) { error = "أضف مقاساً واحداً على الأقل"; return@Button }
                        variants
                    } else {
                        listOf(Variant(stock = parseDigits(stock).toInt().coerceAtLeast(0)))
                    }
                    onSave(
                        Product(
                            name = name.trim(),
                            category = category.ifBlank { "عام" },
                            cost = parseDigits(cost),
                            price = priceL,
                            variants = vars,
                            imagePath = imagePath,
                        )
                    )
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
            ) { Text("حفظ") }
        }
    }
}

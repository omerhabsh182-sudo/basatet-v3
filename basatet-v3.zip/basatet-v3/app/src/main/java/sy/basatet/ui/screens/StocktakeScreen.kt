package sy.basatet.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import sy.basatet.data.StallRepository
import sy.basatet.domain.fmtMoney

@Composable
fun StocktakeScreen(repository: StallRepository, onDone: () -> Unit) {
    val data = repository.data
    var stocktakeId by remember { mutableStateOf<String?>(null) }
    val active = data.stocktakes.firstOrNull { it.id == stocktakeId && it.finishedAt == null }
    val lines = data.products.filter { it.isActive }.flatMap { p ->
        p.variants.map { v -> Triple(p, v, listOf(v.size, v.color).filter { it.isNotBlank() }.joinToString(" / ")) }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("جرد المخزون", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        if (stocktakeId == null) {
            Button(onClick = { stocktakeId = repository.startStocktake() }, modifier = Modifier.fillMaxWidth()) {
                Text("بدء الجرد")
            }
            TextButton(onClick = onDone) { Text("رجوع") }
            val history = data.stocktakes.filter { it.finishedAt != null }.sortedByDescending { it.finishedAt }
            if (history.isNotEmpty()) {
                Text("جرود سابقة", style = MaterialTheme.typography.titleMedium)
                history.take(5).forEach { st ->
                    val shortage = st.lines.filter { it.diff < 0 }.sumOf { -it.valueDiff }
                    val surplus = st.lines.filter { it.diff > 0 }.sumOf { it.valueDiff }
                    Text("نقص ${fmtMoney(shortage)} · زيادة ${fmtMoney(surplus)}${if (st.wasAdjusted) " · عُدّل المخزون" else ""}")
                }
            }
        } else {
            LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(lines, key = { it.second.id }) { (p, v, label) ->
                    var counted by remember(v.id) {
                        mutableStateOf((active?.counted?.get(v.id) ?: v.stock).toString())
                    }
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text("${p.name}${if (label.isNotBlank()) " · $label" else ""}", fontWeight = FontWeight.Medium)
                            Text("في النظام: ${v.stock}")
                            OutlinedTextField(
                                value = counted,
                                onValueChange = {
                                    counted = it.filter { c -> c.isDigit() }
                                    repository.updateStocktakeCount(stocktakeId!!, v.id, counted.toIntOrNull() ?: 0)
                                },
                                label = { Text("العدد الفعلي") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                            )
                        }
                    }
                }
            }
            Button(
                onClick = {
                    repository.finishStocktake(stocktakeId!!, adjustStock = true)
                    stocktakeId = null
                    onDone()
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("إنهاء وتسوية المخزون") }
            OutlinedButton(
                onClick = {
                    repository.finishStocktake(stocktakeId!!, adjustStock = false)
                    stocktakeId = null
                    onDone()
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("إنهاء بدون تسوية") }
        }
    }
}

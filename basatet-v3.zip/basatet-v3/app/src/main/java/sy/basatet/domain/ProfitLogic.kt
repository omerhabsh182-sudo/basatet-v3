package sy.basatet.domain

import sy.basatet.data.ExpenseBucket
import sy.basatet.data.Sale
import sy.basatet.data.StallData
import java.util.Calendar
import kotlin.math.roundToLong

data class PeriodSummary(
    val pieces: Int,
    val revenue: Long,
    val cogs: Long,
    val gross: Long,
    val discounts: Long,
    val devShare: Long,
    val goalShare: Long,
    val expenseShare: Long,
    val leftover: Long,
    val returnedCount: Int,
    val returnedAmount: Long,
)

fun liveSales(data: StallData, since: Long? = null): List<Sale> =
    data.sales.filter {
        !it.isVoided && it.returnedAt == 0L && (since == null || it.soldAt >= since)
    }

fun summarize(data: StallData, since: Long? = null): PeriodSummary {
    val live = liveSales(data, since)
    val revenue = live.sumOf { it.soldPrice }
    val cogs = live.sumOf { it.unitCost }
    val gross = revenue - cogs
    val dev = live.sumOf { it.devShare }
    val goal = live.sumOf { it.goalShare }
    val exp = live.sumOf { it.expenseShare }
    val returned = data.sales.filter { it.returnedAt > 0 && (since == null || it.returnedAt >= since) }
    return PeriodSummary(
        pieces = live.size, revenue = revenue, cogs = cogs, gross = gross,
        discounts = live.sumOf { (it.listPrice - it.soldPrice).coerceAtLeast(0) },
        devShare = dev, goalShare = goal, expenseShare = exp,
        leftover = gross - dev - goal - exp,
        returnedCount = returned.size, returnedAmount = returned.sumOf { it.soldPrice },
    )
}

data class ShareBalances(
    val devAllocated: Long, val devSpent: Long, val devBalance: Long,
    val expAllocated: Long, val expSpent: Long, val expBalance: Long,
    val goalAllocated: Long, val goalFilled: Long,
)

fun shareBalances(data: StallData): ShareBalances {
    val all = summarize(data)
    val devSpent = data.expenses.filter { it.bucket == ExpenseBucket.DEVELOPMENT }.sumOf { it.amount }
    val expSpent = data.expenses.filter { it.bucket == ExpenseBucket.PERSONAL }.sumOf { it.amount }
    val goalFilled = data.goals.sumOf { it.filled }
    return ShareBalances(
        devAllocated = all.devShare, devSpent = devSpent, devBalance = all.devShare - devSpent,
        expAllocated = all.expenseShare, expSpent = expSpent, expBalance = all.expenseShare - expSpent,
        goalAllocated = all.goalShare, goalFilled = goalFilled,
    )
}

fun round2500(n: Long): Long = (n / 2500.0).roundToLong() * 2500L

data class DayBar(val label: String, val profit: Long, val dayStart: Long)
data class HourBar(val hour: Int, val label: String, val pieces: Int, val profit: Long)
data class TopProduct(val productId: String, val name: String, val pieces: Int, val profit: Long)

private val DAY_SHORT = arrayOf("أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت")

fun profitByDay(sales: List<Sale>, days: Int = 7): List<DayBar> {
    val now = System.currentTimeMillis()
    val cal = Calendar.getInstance()
    val buckets = LongArray(days)
    val starts = LongArray(days)
    for (i in 0 until days) {
        starts[i] = startOfDay(now - (days - 1 - i) * 86_400_000L)
    }
    for (s in sales) {
        if (s.isVoided || s.returnedAt > 0) continue
        val diff = ((now - s.soldAt) / 86_400_000L).toInt()
        if (diff in 0 until days) buckets[days - 1 - diff] += s.soldPrice - s.unitCost
    }
    return buckets.mapIndexed { i, profit ->
        cal.timeInMillis = starts[i]
        val label = if (i == days - 1) "اليوم" else DAY_SHORT[cal.get(Calendar.DAY_OF_WEEK) - 1]
        DayBar(label, profit, starts[i])
    }
}

fun bestDay(sales: List<Sale>): DayBar? =
    profitByDay(sales, 30).maxByOrNull { it.profit }?.takeIf { it.profit > 0 }

fun bestHour(sales: List<Sale>): HourBar? {
    val map = mutableMapOf<Int, Pair<Int, Long>>()
    val cal = Calendar.getInstance()
    for (s in sales) {
        if (s.isVoided || s.returnedAt > 0) continue
        cal.timeInMillis = s.soldAt
        val h = cal.get(Calendar.HOUR_OF_DAY)
        val prev = map[h] ?: (0 to 0L)
        map[h] = (prev.first + 1) to (prev.second + (s.soldPrice - s.unitCost))
    }
    return map.maxByOrNull { it.value.second }?.let { (h, v) ->
        HourBar(h, "%02d:00".format(h), v.first, v.second)
    }
}

fun topProducts(sales: List<Sale>, limit: Int = 8): List<TopProduct> {
    val map = mutableMapOf<String, TopProduct>()
    for (s in sales) {
        if (s.isVoided || s.returnedAt > 0) continue
        val e = map[s.productId]
        map[s.productId] = TopProduct(
            s.productId, s.productName,
            (e?.pieces ?: 0) + 1,
            (e?.profit ?: 0L) + (s.soldPrice - s.unitCost),
        )
    }
    return map.values.sortedByDescending { it.profit }.take(limit)
}

fun salesOnDay(sales: List<Sale>, dayStart: Long): List<Sale> {
    val end = dayStart + 86_400_000L
    return sales.filter { !it.isVoided && it.returnedAt == 0L && it.soldAt in dayStart until end }
}

fun startOfDay(ms: Long = System.currentTimeMillis()): Long {
    val c = Calendar.getInstance()
    c.timeInMillis = ms
    c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0)
    c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
    return c.timeInMillis
}

fun startOfWeek(ms: Long = System.currentTimeMillis()): Long {
    val c = Calendar.getInstance()
    c.timeInMillis = ms
    c.firstDayOfWeek = Calendar.SATURDAY
    c.set(Calendar.DAY_OF_WEEK, c.firstDayOfWeek)
    c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0)
    c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
    return c.timeInMillis
}

fun isThursday(): Boolean =
    Calendar.getInstance().get(Calendar.DAY_OF_WEEK) == Calendar.THURSDAY

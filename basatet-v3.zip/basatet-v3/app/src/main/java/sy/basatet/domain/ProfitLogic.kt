package sy.basatet.domain

import sy.basatet.data.Expense
import sy.basatet.data.ExpenseBucket
import sy.basatet.data.Sale
import sy.basatet.data.StallData
import java.util.Calendar
import kotlin.math.roundToLong

// ─────────────────────────────────────────────
// Summary for a period
// ─────────────────────────────────────────────

data class PeriodSummary(
    val pieces: Int,
    val revenue: Long,
    val cogs: Long,
    val gross: Long,
    val discounts: Long,
    val devShare: Long,
    val goalShare: Long,
    val expenseShare: Long,
    val leftover: Long,
    val returnedCount: Int,
    val returnedAmount: Long,
)

fun summarize(data: StallData, since: Long? = null): PeriodSummary {
    val live = data.sales.filter { !it.isVoided && (since == null || it.soldAt >= since) }
    val revenue = live.sumOf { it.soldPrice }
    val cogs = live.sumOf { it.unitCost }
    val gross = revenue - cogs
    val dev = live.sumOf { it.devShare }
    val goal = live.sumOf { it.goalShare }
    val exp = live.sumOf { it.expenseShare }
    val returned = data.sales.filter { it.returnedAt > 0 && (since == null || it.returnedAt >= since) }

    return PeriodSummary(
        pieces = live.size,
        revenue = revenue,
        cogs = cogs,
        gross = gross,
        discounts = live.sumOf { it.listPrice - it.soldPrice },
        devShare = dev,
        goalShare = goal,
        expenseShare = exp,
        leftover = gross - dev - goal - exp,
        returnedCount = returned.size,
        returnedAmount = returned.sumOf { it.soldPrice },
    )
}

// ─────────────────────────────────────────────
// Running balances of the three shares
// ─────────────────────────────────────────────

data class ShareBalances(
    val devAllocated: Long,
    val devSpent: Long,
    val devBalance: Long,
    val expAllocated: Long,
    val expSpent: Long,
    val expBalance: Long,
)

fun shareBalances(data: StallData): ShareBalances {
    val all = summarize(data)
    val devSpent = data.expenses
        .filter { it.bucket == ExpenseBucket.DEVELOPMENT }
        .sumOf { it.amount }
    val expSpent = data.expenses
        .filter { it.bucket == ExpenseBucket.PERSONAL }
        .sumOf { it.amount }

    return ShareBalances(
        devAllocated = all.devShare,
        devSpent = devSpent,
        devBalance = all.devShare - devSpent,
        expAllocated = all.expenseShare,
        expSpent = expSpent,
        expBalance = all.expenseShare - expSpent,
    )
}

/** Round development / saving figures to nearest 2 500. */
fun round2500(n: Long): Long = (n / 2500.0).roundToLong() * 2500L

// ─────────────────────────────────────────────
// Helpers for charts & rankings
// ─────────────────────────────────────────────

data class DayBar(val label: String, val profit: Long)

private val DAY_SHORT = arrayOf("أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت")

fun profitByDay(sales: List<Sale>, days: Int = 7): List<DayBar> {
    val now = System.currentTimeMillis()
    val cal = Calendar.getInstance()
    val result = MutableList(days) { 0L }

    for (s in sales) {
        if (s.isVoided) continue
        val diff = ((now - s.soldAt) / 86_400_000L).toInt()
        if (diff in 0 until days) {
            result[days - 1 - diff] += s.soldPrice - s.unitCost
        }
    }

    return result.mapIndexed { i, profit ->
        cal.timeInMillis = now - (days - 1 - i) * 86_400_000L
        val label = if (i == days - 1) "اليوم" else DAY_SHORT[cal.get(Calendar.DAY_OF_WEEK) - 1]
        DayBar(label, profit)
    }
}

data class TopProduct(val productId: String, val name: String, val pieces: Int, val profit: Long)

fun topProducts(sales: List<Sale>, limit: Int = 8): List<TopProduct> {
    val map = mutableMapOf<String, TopProduct>()
    for (s in sales) {
        if (s.isVoided) continue
        val existing = map[s.productId]
        map[s.productId] = TopProduct(
            productId = s.productId,
            name = s.productName,
            pieces = (existing?.pieces ?: 0) + 1,
            profit = (existing?.profit ?: 0L) + (s.soldPrice - s.unitCost),
        )
    }
    return map.values.sortedByDescending { it.profit }.take(limit)
}

fun startOfDay(ms: Long = System.currentTimeMillis()): Long {
    val c = Calendar.getInstance()
    c.timeInMillis = ms
    c.set(Calendar.HOUR_OF_DAY, 0)
    c.set(Calendar.MINUTE, 0)
    c.set(Calendar.SECOND, 0)
    c.set(Calendar.MILLISECOND, 0)
    return c.timeInMillis
}

fun startOfWeek(ms: Long = System.currentTimeMillis()): Long {
    val c = Calendar.getInstance()
    c.timeInMillis = ms
    c.firstDayOfWeek = Calendar.SATURDAY
    c.set(Calendar.DAY_OF_WEEK, c.firstDayOfWeek)
    c.set(Calendar.HOUR_OF_DAY, 0)
    c.set(Calendar.MINUTE, 0)
    c.set(Calendar.SECOND, 0)
    c.set(Calendar.MILLISECOND, 0)
    return c.timeInMillis
}

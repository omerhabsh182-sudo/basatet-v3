package sy.basatet.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import sy.basatet.data.Product
import sy.basatet.data.StallRepository
import sy.basatet.data.Variant
import sy.basatet.domain.fmtMoney
import sy.basatet.domain.parseDigits
import sy.basatet.domain.priceSyp
import sy.basatet.ui.components.ProductImage

@Composable
fun SellScreen(repository: StallRepository) {
    val data = repository.data
    val products = data.products.filter { it.isActive && it.totalStock > 0 }
    val categories = listOf("الكل") + data.categories

    var selectedCategory by remember { mutableStateOf("الكل") }
    var search by remember { mutableStateOf("") }
    var selectedProduct by remember { mutableStateOf<Product?>(null) }
    var selectedVariant by remember { mutableStateOf<Variant?>(null) }
    var showDiscount by remember { mutableStateOf(false) }
    var customPrice by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var snack by remember { mutableStateOf<String?>(null) }

    val filtered = products.filter { p ->
        (selectedCategory == "الكل" || p.category == selectedCategory) &&
            (search.isBlank() || p.name.contains(search, ignoreCase = true))
    }

    fun completeSale(product: Product, variant: Variant, price: Long?) {
        val result = repository.sell(product.id, variant.id, 1, price)
        if (result.error != null) {
            message = result.error
        } else {
            snack = "تم بيع ${product.name}"
            selectedProduct = null
            showDiscount = false
            customPrice = ""
            message = null
        }
    }

    fun onProductTap(product: Product) {
        message = null
        val inStock = product.variants.filter { it.stock > 0 }
        when {
            inStock.isEmpty() -> return
            inStock.size == 1 && !data.settings.askDiscount -> {
                completeSale(product, inStock.first(), null)
            }
            inStock.size == 1 && data.settings.askDiscount -> {
                selectedProduct = product
                selectedVariant = inStock.first()
                showDiscount = true
            }
            else -> {
                selectedProduct = product
                selectedVariant = null
                showDiscount = false
            }
        }
    }

    Scaffold(
        snackbarHost = {
            snack?.let {
                Snackbar(
                    modifier = Modifier.padding(12.dp),
                    action = {
                        TextButton(onClick = {
                            repository.undoLastSale()
                            snack = "تم التراجع"
                        }) { Text("تراجع") }
                    },
                    dismissAction = {
                        TextButton(onClick = { snack = null }) { Text("حسناً") }
                    },
                ) { Text(it) }
            }
        },
        floatingActionButton = {
            if (repository.lastSoldIds.isNotEmpty()) {
                ExtendedFloatingActionButton(
                    onClick = {
                        val err = repository.undoLastSale()
                        snack = err ?: "تم التراجع عن آخر بيع"
                    },
                    icon = { Icon(Icons.Default.Undo, null) },
                    text = { Text("تراجع") },
                )
            }
        },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                placeholder = { Text("بحث...") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
            )
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(categories) { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat) },
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            if (filtered.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("لا يوجد منتجات متوفرة", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(filtered, key = { it.id }) { product ->
                        ProductSellCard(product, data.settings, repository.imagesDirectory()) { onProductTap(product) }
                    }
                }
            }
        }
    }

    // اختيار المقاس
    if (selectedProduct != null && !showDiscount) {
        val product = selectedProduct!!
        ModalBottomSheet(onDismissRequest = { selectedProduct = null }) {
            Column(Modifier.padding(24.dp).padding(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(product.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("اختر المقاس", style = MaterialTheme.typography.labelLarge)
                product.variants.filter { it.stock > 0 }.forEach { v ->
                    val label = listOf(v.size, v.color).filter { it.isNotBlank() }.joinToString(" / ").ifBlank { "افتراضي" }
                    OutlinedButton(
                        onClick = {
                            selectedVariant = v
                            if (data.settings.askDiscount) showDiscount = true
                            else completeSale(product, v, null)
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text("$label — ${v.stock} متوفر — ${fmtMoney(priceSyp(product, data.settings, v))}")
                    }
                }
            }
        }
    }

    // خصم؟
    if (selectedProduct != null && showDiscount && selectedVariant != null) {
        val product = selectedProduct!!
        val variant = selectedVariant!!
        val list = priceSyp(product, data.settings, variant)
        ModalBottomSheet(onDismissRequest = {
            selectedProduct = null
            showDiscount = false
        }) {
            Column(Modifier.padding(24.dp).padding(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(product.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("السعر الأصلي: ${fmtMoney(list)}")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { completeSale(product, variant, null) },
                        modifier = Modifier.weight(1f),
                    ) { Text("بدون خصم") }
                }
                OutlinedTextField(
                    value = customPrice,
                    onValueChange = { customPrice = it },
                    label = { Text("سعر بعد الخصم") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Button(
                    onClick = {
                        val p = parseDigits(customPrice)
                        if (p <= 0) message = "أدخل سعراً صحيحاً"
                        else completeSale(product, variant, p)
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("بيع بالخصم") }
                message?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        }
    }
}

@Composable
private fun ProductSellCard(
    product: Product,
    settings: sy.basatet.data.Settings,
    imagesDir: java.io.File,
    onClick: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(1.dp),
    ) {
        Row(
            Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            ProductImage(imagePath = product.imagePath, imagesDir = imagesDir, size = 56.dp)
            Column(Modifier.weight(1f)) {
                Text(product.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(
                    "${product.category} · ${product.totalStock} متوفر",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Text(
                fmtMoney(priceSyp(product, settings)),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
            )
        }
    }
}

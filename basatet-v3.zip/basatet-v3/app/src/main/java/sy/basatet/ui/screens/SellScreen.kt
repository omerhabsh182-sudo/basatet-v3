package sy.basatet.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import sy.basatet.data.Product
import sy.basatet.data.StallRepository
import sy.basatet.data.Variant
import sy.basatet.domain.fmtMoney
import sy.basatet.domain.parseDigits
import sy.basatet.domain.priceSyp

@Composable
fun SellScreen(repository: StallRepository) {
    val data = repository.data
    val products = data.products.filter { it.isActive && it.totalStock > 0 }
    val categories = listOf("الكل") + data.categories

    var selectedCategory by remember { mutableStateOf("الكل") }
    var search by remember { mutableStateOf("") }
    var selectedProduct by remember { mutableStateOf<Product?>(null) }
    var selectedVariant by remember { mutableStateOf<Variant?>(null) }
    var quantity by remember { mutableIntStateOf(1) }
    var customPrice by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }

    val filtered = products.filter { p ->
        (selectedCategory == "الكل" || p.category == selectedCategory) &&
        (search.isBlank() || p.name.contains(search, ignoreCase = true))
    }

    Column(Modifier.fillMaxSize()) {
        // Search + categories
        OutlinedTextField(
            value = search,
            onValueChange = { search = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            placeholder = { Text("بحث عن منتج...") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
        )

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(categories) { cat ->
                FilterChip(
                    selected = selectedCategory == cat,
                    onClick = { selectedCategory = cat },
                    label = { Text(cat) },
                )
            }
        }

        Spacer(Modifier.height(8.dp))

        if (filtered.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("لا يوجد منتجات متوفرة", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f),
            ) {
                items(filtered, key = { it.id }) { product ->
                    ProductSellCard(
                        product = product,
                        settings = data.settings,
                        onClick = {
                            selectedProduct = product
                            selectedVariant = product.variants.firstOrNull { it.stock > 0 }
                            quantity = 1
                            customPrice = ""
                            message = null
                        },
                    )
                }
            }
        }
    }

    // Sell bottom sheet
    if (selectedProduct != null) {
        val product = selectedProduct!!
        val variant = selectedVariant
        val listPrice = if (variant != null) priceSyp(product, data.settings, variant) else product.price

        ModalBottomSheet(
            onDismissRequest = { selectedProduct = null },
        ) {
            Column(
                Modifier
                    .padding(horizontal = 24.dp)
                    .padding(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(product.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(product.category, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

                // Variants
                if (product.variants.isNotEmpty()) {
                    Text("المقاس / اللون", style = MaterialTheme.typography.labelLarge)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(product.variants.filter { it.stock > 0 }) { v ->
                            val label = listOf(v.size, v.color).filter { it.isNotBlank() }.joinToString(" / ").ifBlank { "افتراضي" }
                            FilterChip(
                                selected = selectedVariant?.id == v.id,
                                onClick = { selectedVariant = v; quantity = 1 },
                                label = { Text("$label (${v.stock})") },
                            )
                        }
                    }
                }

                // Quantity
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("الكمية", style = MaterialTheme.typography.labelLarge)
                    IconButton(onClick = { if (quantity > 1) quantity-- }) {
                        Icon(Icons.Default.Remove, null)
                    }
                    Text("$quantity", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    IconButton(onClick = {
                        val max = variant?.stock ?: product.totalStock
                        if (quantity < max) quantity++
                    }) {
                        Icon(Icons.Default.Add, null)
                    }
                }

                // Price
                val finalPrice = if (customPrice.isNotBlank()) parseDigits(customPrice) else listPrice
                OutlinedTextField(
                    value = customPrice,
                    onValueChange = { customPrice = it },
                    label = { Text("السعر (اتركه فارغ للسعر الأصلي)") },
                    placeholder = { Text(fmtMoney(listPrice)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )

                Text(
                    "الإجمالي: ${fmtMoney(finalPrice * quantity)}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                )

                message?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                }

                Button(
                    onClick = {
                        if (variant == null) {
                            message = "اختر مقاس / لون"
                            return@Button
                        }
                        val result = repository.sell(
                            productId = product.id,
                            variantId = variant.id,
                            quantity = quantity,
                            finalPrice = if (customPrice.isNotBlank()) parseDigits(customPrice) else null,
                        )
                        if (result.error != null) {
                            message = result.error
                        } else {
                            selectedProduct = null
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                ) {
                    Text("تأكيد البيع", style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }
}

@Composable
private fun ProductSellCard(
    product: Product,
    settings: sy.basatet.data.Settings,
    onClick: () -> Unit,
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Row(
            Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(product.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(
                    "${product.category} · ${product.totalStock} متوفر",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Text(
                fmtMoney(priceSyp(product, settings)),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
            )
        }
    }
}

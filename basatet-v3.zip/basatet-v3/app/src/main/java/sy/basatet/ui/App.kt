package sy.basatet.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.PointOfSale
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import sy.basatet.data.StallRepository
import sy.basatet.ui.screens.HomeScreen
import sy.basatet.ui.screens.ProductsScreen
import sy.basatet.ui.screens.ProfitScreen
import sy.basatet.ui.screens.SellScreen
import sy.basatet.ui.screens.SettingsScreen

sealed class Dest(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
) {
    data object Home : Dest("home", "الرئيسية", Icons.Filled.Home, Icons.Outlined.Home)
    data object Sell : Dest("sell", "بيع", Icons.Filled.PointOfSale, Icons.Outlined.PointOfSale)
    data object Products : Dest("products", "المخزون", Icons.Filled.Inventory2, Icons.Outlined.Inventory2)
    data object Profit : Dest("profit", "الأرباح", Icons.Filled.TrendingUp, Icons.Outlined.TrendingUp)
    data object Settings : Dest("settings", "الإعدادات", Icons.Filled.Settings, Icons.Outlined.Settings)
}

private val bottomDestinations = listOf(
    Dest.Home, Dest.Sell, Dest.Products, Dest.Profit, Dest.Settings
)

@Composable
fun App(repository: StallRepository) {
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val current = backStack?.destination

    Scaffold(
        bottomBar = {
            NavigationBar {
                bottomDestinations.forEach { dest ->
                    val selected = current?.hierarchy?.any { it.route == dest.route } == true
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            navController.navigate(dest.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = {
                            Icon(
                                imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                contentDescription = dest.label,
                            )
                        },
                        label = { Text(dest.label) },
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Dest.Home.route,
            modifier = Modifier.padding(padding),
        ) {
            composable(Dest.Home.route) { HomeScreen(repository) }
            composable(Dest.Sell.route) { SellScreen(repository) }
            composable(Dest.Products.route) { ProductsScreen(repository) }
            composable(Dest.Profit.route) { ProfitScreen(repository) }
            composable(Dest.Settings.route) { SettingsScreen(repository) }
        }
    }
}

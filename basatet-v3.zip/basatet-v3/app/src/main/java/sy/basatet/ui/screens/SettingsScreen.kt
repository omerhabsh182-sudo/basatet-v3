package sy.basatet.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import sy.basatet.data.StallRepository
import sy.basatet.domain.parseDigits

@Composable
fun SettingsScreen(repository: StallRepository) {
    val data = repository.data
    val s = data.settings

    var devPct by remember { mutableStateOf(s.devPercent.toString()) }
    var goalsPct by remember { mutableStateOf(s.goalsPercent.toString()) }
    var expPct by remember { mutableStateOf(s.expensesPercent.toString()) }
    var roundStep by remember { mutableStateOf(s.roundStep.toString()) }
    var askDiscount by remember { mutableStateOf(s.askDiscount) }
    var saved by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("الإعدادات", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        Text("تقسيم الأرباح (%)", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(
                value = devPct,
                onValueChange = { devPct = it },
                label = { Text("تطوير") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.weight(1f),
            )
            OutlinedTextField(
                value = goalsPct,
                onValueChange = { goalsPct = it },
                label = { Text("أهداف") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.weight(1f),
            )
            OutlinedTextField(
                value = expPct,
                onValueChange = { expPct = it },
                label = { Text("مصروف") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.weight(1f),
            )
        }

        OutlinedTextField(
            value = roundStep,
            onValueChange = { roundStep = it },
            label = { Text("تقريب الأسعار إلى أقرب") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text("السؤال عن الخصم عند البيع", style = MaterialTheme.typography.bodyLarge)
            Switch(checked = askDiscount, onCheckedChange = { askDiscount = it })
        }

        Button(
            onClick = {
                val d = parseDigits(devPct).toInt().coerceIn(0, 100)
                val g = parseDigits(goalsPct).toInt().coerceIn(0, 100)
                val e = parseDigits(expPct).toInt().coerceIn(0, 100)
                val r = parseDigits(roundStep).toInt().coerceAtLeast(1)
                repository.updateSettings(
                    s.copy(
                        devPercent = d,
                        goalsPercent = g,
                        expensesPercent = e,
                        roundStep = r,
                        askDiscount = askDiscount,
                    )
                )
                saved = true
            },
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) {
            Text("حفظ الإعدادات")
        }

        if (saved) {
            Text("تم الحفظ", color = MaterialTheme.colorScheme.primary)
        }

        HorizontalDivider()
        Text("الإصدار 3.0.0", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("بسطتي — إدارة البسطة", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

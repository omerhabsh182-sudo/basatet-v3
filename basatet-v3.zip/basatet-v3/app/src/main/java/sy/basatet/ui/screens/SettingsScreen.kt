package sy.basatet.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import sy.basatet.data.APP_NAME
import sy.basatet.data.StallRepository
import sy.basatet.domain.parseDigits
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SettingsScreen(repository: StallRepository) {
    val data = repository.data
    val s = data.settings
    var devPct by remember { mutableStateOf(s.devPercent.toString()) }
    var goalsPct by remember { mutableStateOf(s.goalsPercent.toString()) }
    var expPct by remember { mutableStateOf(s.expensesPercent.toString()) }
    var roundStep by remember { mutableStateOf(s.roundStep.toString()) }
    var askDiscount by remember { mutableStateOf(s.askDiscount) }
    var msg by remember { mutableStateOf<String?>(null) }
    var confirmReset by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("الإعدادات", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        Text("تقسيم الأرباح (%)", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(devPct, { devPct = it }, label = { Text("تطوير") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
            OutlinedTextField(goalsPct, { goalsPct = it }, label = { Text("تصميد") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
            OutlinedTextField(expPct, { expPct = it }, label = { Text("مصروف") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
        }
        OutlinedTextField(roundStep, { roundStep = it }, label = { Text("تقريب الأسعار") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("السؤال عن الخصم عند البيع")
            Switch(checked = askDiscount, onCheckedChange = { askDiscount = it })
        }
        Button(
            onClick = {
                repository.updateSettings(
                    s.copy(
                        devPercent = parseDigits(devPct).toInt().coerceIn(0, 100),
                        goalsPercent = parseDigits(goalsPct).toInt().coerceIn(0, 100),
                        expensesPercent = parseDigits(expPct).toInt().coerceIn(0, 100),
                        roundStep = parseDigits(roundStep).toInt().coerceAtLeast(1),
                        askDiscount = askDiscount,
                    )
                )
                msg = "تم الحفظ"
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("حفظ الإعدادات") }

        HorizontalDivider()
        Text("النسخ الاحتياطي", style = MaterialTheme.typography.titleMedium)
        if (s.lastBackupAt > 0) {
            val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
            Text("آخر نسخة: ${fmt.format(Date(s.lastBackupAt))}")
        }
        Button(
            onClick = {
                val f = repository.exportBackup()
                msg = "نسخة محفوظة: ${f.name}"
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("نسخة احتياطية الآن") }

        val backups = repository.listBackups()
        backups.take(5).forEach { file ->
            OutlinedButton(
                onClick = {
                    msg = repository.restoreBackup(file) ?: "تمت الاستعادة من ${file.name}"
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("استعادة: ${file.name}") }
        }

        HorizontalDivider()
        Text("خطر", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.error)
        OutlinedButton(
            onClick = { confirmReset = true },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
        ) { Text("تصفير الأرباح (بدون المساس بالمخزون)") }

        if (confirmReset) {
            AlertDialog(
                onDismissRequest = { confirmReset = false },
                title = { Text("تأكيد التصفير") },
                text = { Text("سيتم حذف سجل المبيعات والمصروفات وأرصدة التصميد. المخزون يبقى كما هو.") },
                confirmButton = {
                    TextButton(onClick = {
                        repository.resetProfits()
                        confirmReset = false
                        msg = "تم تصفير الأرباح"
                    }) { Text("تصفير") }
                },
                dismissButton = {
                    TextButton(onClick = { confirmReset = false }) { Text("إلغاء") }
                },
            )
        }

        msg?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
        HorizontalDivider()
        Text("$APP_NAME — الإصدار 3.1.0", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("مجاني · بياناتك على جهازك فقط", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

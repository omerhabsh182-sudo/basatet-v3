package sy.basatet.data

import org.json.JSONArray
import org.json.JSONObject

object StallJson {

    fun toJson(data: StallData): JSONObject = JSONObject().apply {
        put("categories", JSONArray(data.categories))
        put("settings", settingsToJson(data.settings))
        put("products", JSONArray(data.products.map { productToJson(it) }))
        put("sales", JSONArray(data.sales.map { saleToJson(it) }))
        put("purchases", JSONArray(data.purchases.map { purchaseToJson(it) }))
        put("expenses", JSONArray(data.expenses.map { expenseToJson(it) }))
        put("goals", JSONArray(data.goals.map { goalToJson(it) }))
        put("stocktakes", JSONArray(data.stocktakes.map { stocktakeToJson(it) }))
    }

    fun fromJson(root: JSONObject): StallData {
        return StallData(
            categories = root.optJSONArray("categories")?.toStringList() ?: DEFAULT_CATEGORIES,
            settings = root.optJSONObject("settings")?.let { settingsFromJson(it) } ?: Settings(),
            products = root.optJSONArray("products")?.mapObjects { productFromJson(it) } ?: emptyList(),
            sales = root.optJSONArray("sales")?.mapObjects { saleFromJson(it) } ?: emptyList(),
            purchases = root.optJSONArray("purchases")?.mapObjects { purchaseFromJson(it) } ?: emptyList(),
            expenses = root.optJSONArray("expenses")?.mapObjects { expenseFromJson(it) } ?: emptyList(),
            goals = root.optJSONArray("goals")?.mapObjects { goalFromJson(it) } ?: emptyList(),
            stocktakes = root.optJSONArray("stocktakes")?.mapObjects { stocktakeFromJson(it) } ?: emptyList(),
        )
    }

    private fun settingsToJson(s: Settings) = JSONObject().apply {
        put("roundStep", s.roundStep)
        put("viewMode", s.viewMode.name)
        put("askDiscount", s.askDiscount)
        put("devPercent", s.devPercent)
        put("goalsPercent", s.goalsPercent)
        put("expensesPercent", s.expensesPercent)
        put("savingName", s.savingName)
        put("themeId", s.themeId)
        put("showTodayStats", s.showTodayStats)
        put("cashOnHand", s.cashOnHand)
        put("cornerRadius", s.cornerRadius)
        put("fontScale", s.fontScale.toDouble())
        put("lastBackupAt", s.lastBackupAt)
    }

    private fun settingsFromJson(j: JSONObject) = Settings(
        roundStep = j.optInt("roundStep", 5),
        viewMode = runCatching { ViewMode.valueOf(j.optString("viewMode", "GRID2")) }.getOrDefault(ViewMode.GRID2),
        askDiscount = j.optBoolean("askDiscount", true),
        devPercent = j.optInt("devPercent", 50),
        goalsPercent = j.optInt("goalsPercent", 45),
        expensesPercent = j.optInt("expensesPercent", 5),
        savingName = j.optString("savingName", "التصميد"),
        themeId = j.optString("themeId", "emerald"),
        showTodayStats = j.optBoolean("showTodayStats", true),
        cashOnHand = j.optLong("cashOnHand", 0L),
        cornerRadius = j.optInt("cornerRadius", 12),
        fontScale = j.optDouble("fontScale", 1.0).toFloat(),
        lastBackupAt = j.optLong("lastBackupAt", 0L),
    )

    private fun productToJson(p: Product) = JSONObject().apply {
        put("id", p.id); put("name", p.name); put("category", p.category)
        put("cost", p.cost); put("price", p.price)
        put("variants", JSONArray(p.variants.map { variantToJson(it) }))
        put("imagePath", p.imagePath); put("isActive", p.isActive); put("createdAt", p.createdAt)
    }

    private fun productFromJson(j: JSONObject) = Product(
        id = j.getString("id"), name = j.getString("name"), category = j.optString("category", ""),
        cost = j.optLong("cost", 0L), price = j.optLong("price", 0L),
        variants = j.optJSONArray("variants")?.mapObjects { variantFromJson(it) } ?: emptyList(),
        imagePath = j.optString("imagePath", ""), isActive = j.optBoolean("isActive", true),
        createdAt = j.optLong("createdAt", 0L),
    )

    private fun variantToJson(v: Variant) = JSONObject().apply {
        put("id", v.id); put("size", v.size); put("color", v.color); put("stock", v.stock)
        if (v.priceOverride != null) put("priceOverride", v.priceOverride)
    }

    private fun variantFromJson(j: JSONObject) = Variant(
        id = j.getString("id"), size = j.optString("size", ""), color = j.optString("color", ""),
        stock = j.optInt("stock", 0),
        priceOverride = if (j.has("priceOverride")) j.getLong("priceOverride") else null,
    )

    private fun saleToJson(s: Sale) = JSONObject().apply {
        put("id", s.id); put("productId", s.productId); put("variantId", s.variantId)
        put("productName", s.productName); put("category", s.category)
        put("size", s.size); put("color", s.color)
        put("listPrice", s.listPrice); put("soldPrice", s.soldPrice); put("unitCost", s.unitCost)
        put("devShare", s.devShare); put("goalShare", s.goalShare); put("expenseShare", s.expenseShare)
        put("soldAt", s.soldAt); put("isVoided", s.isVoided); put("returnedAt", s.returnedAt)
    }

    private fun saleFromJson(j: JSONObject) = Sale(
        id = j.getString("id"), productId = j.getString("productId"), variantId = j.getString("variantId"),
        productName = j.optString("productName", ""), category = j.optString("category", ""),
        size = j.optString("size", ""), color = j.optString("color", ""),
        listPrice = j.optLong("listPrice", 0L), soldPrice = j.optLong("soldPrice", 0L),
        unitCost = j.optLong("unitCost", 0L),
        devShare = j.optLong("devShare", 0L), goalShare = j.optLong("goalShare", 0L),
        expenseShare = j.optLong("expenseShare", 0L),
        soldAt = j.optLong("soldAt", 0L), isVoided = j.optBoolean("isVoided", false),
        returnedAt = j.optLong("returnedAt", 0L),
    )

    private fun purchaseToJson(p: Purchase) = JSONObject().apply {
        put("id", p.id); put("productId", p.productId); put("productName", p.productName)
        put("label", p.label); put("quantity", p.quantity); put("unitCost", p.unitCost)
        put("totalSyp", p.totalSyp); put("kind", p.kind.name); put("supplier", p.supplier)
        put("note", p.note); put("purchasedAt", p.purchasedAt)
    }

    private fun purchaseFromJson(j: JSONObject) = Purchase(
        id = j.getString("id"), productId = j.getString("productId"),
        productName = j.optString("productName", ""), label = j.optString("label", ""),
        quantity = j.optInt("quantity", 0), unitCost = j.optLong("unitCost", 0L),
        totalSyp = j.optLong("totalSyp", 0L),
        kind = runCatching { PurchaseKind.valueOf(j.optString("kind", "RESTOCK")) }.getOrDefault(PurchaseKind.RESTOCK),
        supplier = j.optString("supplier", ""), note = j.optString("note", ""),
        purchasedAt = j.optLong("purchasedAt", 0L),
    )

    private fun expenseToJson(e: Expense) = JSONObject().apply {
        put("id", e.id); put("title", e.title); put("amount", e.amount)
        put("bucket", e.bucket.name); put("createdAt", e.createdAt)
    }

    private fun expenseFromJson(j: JSONObject) = Expense(
        id = j.getString("id"), title = j.optString("title", ""), amount = j.optLong("amount", 0L),
        bucket = runCatching { ExpenseBucket.valueOf(j.optString("bucket", "PERSONAL")) }.getOrDefault(ExpenseBucket.PERSONAL),
        createdAt = j.optLong("createdAt", 0L),
    )

    private fun goalToJson(g: Goal) = JSONObject().apply {
        put("id", g.id); put("name", g.name); put("target", g.target)
        put("filled", g.filled); put("priority", g.priority)
        // backward compat: spent -> filled
        if (g.achievedAt != null) put("achievedAt", g.achievedAt)
    }

    private fun goalFromJson(j: JSONObject) = Goal(
        id = j.getString("id"), name = j.optString("name", ""),
        target = j.optLong("target", 0L),
        filled = if (j.has("filled")) j.optLong("filled", 0L) else j.optLong("spent", 0L),
        priority = j.optInt("priority", 0),
        achievedAt = if (j.has("achievedAt")) j.getLong("achievedAt") else null,
    )

    private fun stocktakeToJson(s: Stocktake) = JSONObject().apply {
        put("id", s.id); put("startedAt", s.startedAt)
        if (s.finishedAt != null) put("finishedAt", s.finishedAt)
        put("counted", JSONObject(s.counted.mapKeys { it.key }))
        put("lines", JSONArray(s.lines.map { lineToJson(it) }))
        put("wasAdjusted", s.wasAdjusted)
    }

    private fun stocktakeFromJson(j: JSONObject): Stocktake {
        val countedObj = j.optJSONObject("counted") ?: JSONObject()
        val counted = mutableMapOf<String, Int>()
        countedObj.keys().forEach { key -> counted[key] = countedObj.optInt(key, 0) }
        return Stocktake(
            id = j.getString("id"),
            startedAt = j.optLong("startedAt", 0L),
            finishedAt = if (j.has("finishedAt")) j.getLong("finishedAt") else null,
            counted = counted,
            lines = j.optJSONArray("lines")?.mapObjects { lineFromJson(it) } ?: emptyList(),
            wasAdjusted = j.optBoolean("wasAdjusted", false),
        )
    }

    private fun lineToJson(l: CountLine) = JSONObject().apply {
        put("productId", l.productId); put("variantId", l.variantId)
        put("name", l.name); put("label", l.label)
        put("expected", l.expected); put("counted", l.counted); put("unitCost", l.unitCost)
    }

    private fun lineFromJson(j: JSONObject) = CountLine(
        productId = j.getString("productId"), variantId = j.getString("variantId"),
        name = j.optString("name", ""), label = j.optString("label", ""),
        expected = j.optInt("expected", 0), counted = j.optInt("counted", 0),
        unitCost = j.optLong("unitCost", 0L),
    )

    private fun JSONArray.toStringList(): List<String> = (0 until length()).map { optString(it) }
    private fun <T> JSONArray.mapObjects(transform: (JSONObject) -> T): List<T> =
        (0 until length()).map { transform(getJSONObject(it)) }
}

package sy.basatet.data

import java.util.UUID

// ─────────────────────────────────────────────
// Constants
// ─────────────────────────────────────────────

const val APP_NAME = "بسطتي"
val DEFAULT_CATEGORIES = listOf("بيجامات", "مكياج")

// ─────────────────────────────────────────────
// View modes
// ─────────────────────────────────────────────

enum class ViewMode(val label: String, val columns: Int) {
    LIST("قائمة", 1),
    GRID2("شبكة ٢", 2),
    GRID3("مربعات", 3),
    CARDS("بطاقات", 1),
}

// ─────────────────────────────────────────────
// Core entities
// ─────────────────────────────────────────────

data class Variant(
    val id: String = UUID.randomUUID().toString(),
    val size: String = "",
    val color: String = "",
    val stock: Int = 0,
    val priceOverride: Long? = null,   // null = use product price
)

data class Product(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val category: String,
    val cost: Long,                    // cost in SYP
    val price: Long,                   // list price in SYP
    val variants: List<Variant> = emptyList(),
    val imagePath: String = "",
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
) {
    val totalStock: Int get() = variants.sumOf { it.stock }
}

data class Sale(
    val id: String = UUID.randomUUID().toString(),
    val productId: String,
    val variantId: String,
    val productName: String,
    val category: String,
    val size: String,
    val color: String,
    val listPrice: Long,
    val soldPrice: Long,
    val unitCost: Long,
    val devShare: Long = 0L,
    val goalShare: Long = 0L,
    val expenseShare: Long = 0L,
    val soldAt: Long = System.currentTimeMillis(),
    val isVoided: Boolean = false,
    val returnedAt: Long = 0L,
)

data class Purchase(
    val id: String = UUID.randomUUID().toString(),
    val productId: String,
    val productName: String,
    val label: String,
    val quantity: Int,
    val unitCost: Long,
    val totalSyp: Long,
    val kind: PurchaseKind,
    val supplier: String = "",
    val note: String = "",
    val purchasedAt: Long = System.currentTimeMillis(),
)

enum class PurchaseKind(val label: String) {
    RESTOCK("تجديد"),
    NEW("قطعة جديدة"),
}

data class Expense(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val amount: Long,
    val bucket: ExpenseBucket,
    val createdAt: Long = System.currentTimeMillis(),
)

enum class ExpenseBucket(val label: String) {
    DEVELOPMENT("تطوير البسطة"),
    PERSONAL("مصروف شخصي"),
}

data class Goal(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val target: Long,
    val spent: Long = 0L,
    val achievedAt: Long? = null,
)

data class CountLine(
    val productId: String,
    val variantId: String,
    val name: String,
    val label: String,
    val expected: Int,
    val counted: Int,
    val unitCost: Long,
)

data class Stocktake(
    val id: String = UUID.randomUUID().toString(),
    val startedAt: Long = System.currentTimeMillis(),
    val finishedAt: Long? = null,
    val counted: Map<String, Int> = emptyMap(),
    val lines: List<CountLine> = emptyList(),
    val wasAdjusted: Boolean = false,
)

// ─────────────────────────────────────────────
// Settings
// ─────────────────────────────────────────────

data class Settings(
    val roundStep: Int = 5,
    val viewMode: ViewMode = ViewMode.GRID2,
    val askDiscount: Boolean = true,
    val devPercent: Int = 50,
    val goalsPercent: Int = 45,
    val expensesPercent: Int = 5,
    val savingName: String = "التصميد",
    val themeId: String = "aurora",
    val showTodayStats: Boolean = true,
)

// ─────────────────────────────────────────────
// Root data container
// ─────────────────────────────────────────────

data class StallData(
    val categories: List<String> = DEFAULT_CATEGORIES,
    val settings: Settings = Settings(),
    val products: List<Product> = emptyList(),
    val sales: List<Sale> = emptyList(),
    val purchases: List<Purchase> = emptyList(),
    val expenses: List<Expense> = emptyList(),
    val goals: List<Goal> = emptyList(),
    val stocktakes: List<Stocktake> = emptyList(),
)

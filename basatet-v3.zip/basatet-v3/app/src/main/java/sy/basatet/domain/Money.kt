package sy.basatet.domain

import sy.basatet.data.Product
import sy.basatet.data.Settings
import sy.basatet.data.Variant
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.roundToLong

private val US = Locale.US

fun fmtNum(n: Long): String = NumberFormat.getIntegerInstance(US).format(n)

fun fmtMoney(n: Long): String = "${fmtNum(n)} ل.س"

fun fmtPct(ratio: Double): String = "${(ratio * 100).roundToLong()}%"

/** Convert any digit script (Arabic-Indic / Persian / Western) to Long. */
fun parseDigits(raw: String): Long {
    val sb = StringBuilder()
    for (c in raw) {
        when (c) {
            in '0'..'9' -> sb.append(c)
            in '٠'..'٩' -> sb.append('0' + (c - '٠'))
            in '۰'..'۹' -> sb.append('0' + (c - '۰'))
        }
    }
    return sb.toString().toLongOrNull() ?: 0L
}

fun parseDouble(raw: String): Double {
    val cleaned = raw
        .replace('٫', '.')
        .replace('،', '.')
        .filter { it.isDigit() || it == '.' || it == '-' }
    return cleaned.toDoubleOrNull() ?: 0.0
}

/** Round to nearest step (e.g. 5, 10, 25…). */
fun roundToStep(value: Long, step: Int): Long {
    if (step <= 1) return value
    return ((value.toDouble() / step).roundToLong() * step)
}

/** Cost of one unit in Syrian pounds. */
fun costSyp(product: Product): Long = product.cost.coerceAtLeast(0)

/** List price of a specific variant in Syrian pounds. */
fun priceSyp(product: Product, settings: Settings, variant: Variant? = null): Long {
    val override = variant?.priceOverride
    if (override != null) return override
    return roundToStep(product.price, settings.roundStep).coerceAtLeast(0)
}

fun pieceWord(n: Int): String = when (n) {
    1 -> "قطعة"
    2 -> "قطعتان"
    in 3..10 -> "قطع"
    else -> "قطعة"
}

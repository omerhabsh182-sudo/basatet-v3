package sy.basatet.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONObject
import sy.basatet.domain.costSyp
import sy.basatet.domain.priceSyp
import java.io.File
import java.util.UUID
import kotlin.math.roundToLong

class StallRepository(private val context: Context) {

    private val dataFile = File(context.filesDir, "stall.json")
    private val imagesDir = File(context.filesDir, "images").also { it.mkdirs() }

    var data by mutableStateOf(load())
        private set

    private fun load(): StallData {
        if (!dataFile.exists()) return StallData()
        return try {
            val json = dataFile.readText(Charsets.UTF_8)
            StallJson.fromJson(JSONObject(json))
        } catch (e: Exception) {
            dataFile.renameTo(File(context.filesDir, "stall.corrupt-${System.currentTimeMillis()}.json"))
            StallData()
        }
    }

    private fun commit(next: StallData) {
        data = next
        val tmp = File(context.filesDir, "stall.json.tmp")
        tmp.writeText(StallJson.toJson(next).toString(), Charsets.UTF_8)
        if (!tmp.renameTo(dataFile)) {
            dataFile.delete()
            tmp.renameTo(dataFile)
        }
    }

    // ── Products ─────────────────────────────────

    fun addProduct(product: Product) {
        commit(data.copy(products = data.products + product))
    }

    fun updateProduct(product: Product) {
        commit(data.copy(products = data.products.map { if (it.id == product.id) product else it }))
    }

    fun deactivateProduct(id: String) {
        commit(data.copy(products = data.products.map {
            if (it.id == id) it.copy(isActive = false) else it
        }))
    }

    // ── Sales ────────────────────────────────────

    data class SellResult(val error: String? = null, val soldIds: List<String> = emptyList())

    fun sell(
        productId: String,
        variantId: String,
        quantity: Int,
        finalPrice: Long? = null,
    ): SellResult {
        if (quantity < 1) return SellResult("اختر قطعة واحدة على الأقل")

        val product = data.products.firstOrNull { it.id == productId && it.isActive }
            ?: return SellResult("القطعة غير موجودة")
        val variant = product.variants.firstOrNull { it.id == variantId }
            ?: return SellResult("اختر المقاس / اللون")
        if (quantity > variant.stock) {
            return SellResult("المتوفر من هذا الخيار ${variant.stock} فقط")
        }

        val settings = data.settings
        val list = priceSyp(product, settings, variant)
        val unit = (finalPrice ?: list).coerceAtLeast(0)
        val cost = costSyp(product)
        val profit = (unit - cost).coerceAtLeast(0)

        fun share(pct: Int) = (profit * pct / 100.0).roundToLong()

        val now = System.currentTimeMillis()
        val newSales = List(quantity) { i ->
            Sale(
                id = UUID.randomUUID().toString(),
                productId = product.id,
                variantId = variant.id,
                productName = product.name,
                category = product.category,
                size = variant.size,
                color = variant.color,
                listPrice = list,
                soldPrice = unit,
                unitCost = cost,
                devShare = share(settings.devPercent),
                goalShare = share(settings.goalsPercent),
                expenseShare = share(settings.expensesPercent),
                soldAt = now + i,
            )
        }

        val updatedVariants = product.variants.map {
            if (it.id == variantId) it.copy(stock = it.stock - quantity) else it
        }
        val updatedProduct = product.copy(variants = updatedVariants)

        commit(
            data.copy(
                products = data.products.map { if (it.id == productId) updatedProduct else it },
                sales = data.sales + newSales,
            )
        )
        return SellResult(soldIds = newSales.map { it.id })
    }

    fun voidSale(saleId: String) {
        val sale = data.sales.firstOrNull { it.id == saleId } ?: return
        if (sale.isVoided) return

        val products = data.products.map { p ->
            if (p.id != sale.productId) p
            else p.copy(variants = p.variants.map { v ->
                if (v.id == sale.variantId) v.copy(stock = v.stock + 1) else v
            })
        }
        val sales = data.sales.map {
            if (it.id == saleId) it.copy(isVoided = true) else it
        }
        commit(data.copy(products = products, sales = sales))
    }

    fun returnSale(saleId: String) {
        val sale = data.sales.firstOrNull { it.id == saleId } ?: return
        if (sale.isVoided || sale.returnedAt > 0) return

        val products = data.products.map { p ->
            if (p.id != sale.productId) p
            else p.copy(variants = p.variants.map { v ->
                if (v.id == sale.variantId) v.copy(stock = v.stock + 1) else v
            })
        }
        val sales = data.sales.map {
            if (it.id == saleId) it.copy(returnedAt = System.currentTimeMillis()) else it
        }
        commit(data.copy(products = products, sales = sales))
    }

    // ── Purchases / Restock ──────────────────────

    fun restockVariant(productId: String, variantId: String, qty: Int, unitCost: Long) {
        if (qty < 1) return
        val product = data.products.firstOrNull { it.id == productId } ?: return

        val updatedVariants = product.variants.map {
            if (it.id == variantId) it.copy(stock = it.stock + qty) else it
        }
        val updatedProduct = product.copy(variants = updatedVariants)

        val label = product.variants.firstOrNull { it.id == variantId }
            ?.let { listOf(it.size, it.color).filter { s -> s.isNotBlank() }.joinToString(" / ") }
            ?: ""

        val purchase = Purchase(
            productId = productId,
            productName = product.name,
            label = label,
            quantity = qty,
            unitCost = unitCost,
            totalSyp = unitCost * qty,
            kind = PurchaseKind.RESTOCK,
        )

        commit(
            data.copy(
                products = data.products.map { if (it.id == productId) updatedProduct else it },
                purchases = data.purchases + purchase,
            )
        )
    }

    // ── Expenses & Goals ─────────────────────────

    fun addExpense(expense: Expense) {
        commit(data.copy(expenses = data.expenses + expense))
    }

    fun removeExpense(id: String) {
        commit(data.copy(expenses = data.expenses.filter { it.id != id }))
    }

    fun addGoal(goal: Goal) {
        commit(data.copy(goals = data.goals + goal))
    }

    fun updateGoal(goal: Goal) {
        commit(data.copy(goals = data.goals.map { if (it.id == goal.id) goal else it }))
    }

    fun removeGoal(id: String) {
        commit(data.copy(goals = data.goals.filter { it.id != id }))
    }

    // ── Settings & Categories ────────────────────

    fun updateSettings(settings: Settings) {
        commit(data.copy(settings = settings))
    }

    fun setCategories(categories: List<String>) {
        commit(data.copy(categories = categories.distinct().filter { it.isNotBlank() }))
    }

    // ── Stocktake ────────────────────────────────

    fun startStocktake(): String {
        val id = UUID.randomUUID().toString()
        val st = Stocktake(id = id)
        commit(data.copy(stocktakes = data.stocktakes + st))
        return id
    }

    fun updateStocktakeCount(stocktakeId: String, variantId: String, counted: Int) {
        commit(data.copy(stocktakes = data.stocktakes.map { st ->
            if (st.id != stocktakeId) st
            else st.copy(counted = st.counted + (variantId to counted))
        }))
    }

    fun finishStocktake(stocktakeId: String, adjustStock: Boolean) {
        val st = data.stocktakes.firstOrNull { it.id == stocktakeId } ?: return
        val lines = mutableListOf<CountLine>()
        var products = data.products

        for (p in data.products.filter { it.isActive }) {
            for (v in p.variants) {
                val counted = st.counted[v.id] ?: 0
                val cost = costSyp(p)
                lines += CountLine(
                    productId = p.id,
                    variantId = v.id,
                    name = p.name,
                    label = listOf(v.size, v.color).filter { it.isNotBlank() }.joinToString(" / "),
                    expected = v.stock,
                    counted = counted,
                    unitCost = cost,
                )
                if (adjustStock && counted != v.stock) {
                    products = products.map { prod ->
                        if (prod.id != p.id) prod
                        else prod.copy(variants = prod.variants.map { vv ->
                            if (vv.id == v.id) vv.copy(stock = counted) else vv
                        })
                    }
                }
            }
        }

        val finished = st.copy(
            finishedAt = System.currentTimeMillis(),
            lines = lines,
            wasAdjusted = adjustStock,
        )
        commit(
            data.copy(
                products = products,
                stocktakes = data.stocktakes.map { if (it.id == stocktakeId) finished else it },
            )
        )
    }

    fun imagesDirectory(): File = imagesDir

    fun cleanupOrphanImages() {
        val used = data.products.map { it.imagePath }.filter { it.isNotBlank() }.toSet()
        imagesDir.listFiles()?.forEach { f ->
            if (f.name !in used) f.delete()
        }
    }
}

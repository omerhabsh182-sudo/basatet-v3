package sy.basatet.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONObject
import sy.basatet.domain.costSyp
import sy.basatet.domain.priceSyp
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.roundToLong

class StallRepository(private val context: Context) {

    private val dataFile = File(context.filesDir, "stall.json")
    private val imagesDir = File(context.filesDir, "images").also { it.mkdirs() }
    private val backupDir = File(context.getExternalFilesDir(null), "backups").also { it.mkdirs() }

    var data by mutableStateOf(load())
        private set

    var lastSoldIds by mutableStateOf<List<String>>(emptyList())
        private set

    private fun load(): StallData {
        if (!dataFile.exists()) return StallData()
        return try {
            StallJson.fromJson(JSONObject(dataFile.readText(Charsets.UTF_8)))
        } catch (e: Exception) {
            dataFile.renameTo(File(context.filesDir, "stall.corrupt-${System.currentTimeMillis()}.json"))
            StallData()
        }
    }

    private fun commit(next: StallData) {
        data = next
        val tmp = File(context.filesDir, "stall.json.tmp")
        tmp.writeText(StallJson.toJson(next).toString(), Charsets.UTF_8)
        if (!tmp.renameTo(dataFile)) {
            dataFile.delete()
            tmp.renameTo(dataFile)
        }
    }

    // ── Products ─────────────────────────────────

    fun addProduct(product: Product) {
        commit(data.copy(products = data.products + product))
    }

    fun updateProduct(product: Product) {
        commit(data.copy(products = data.products.map { if (it.id == product.id) product else it }))
    }

    fun deactivateProduct(id: String) {
        commit(data.copy(products = data.products.map {
            if (it.id == id) it.copy(isActive = false) else it
        }))
    }

    // ── Sales ────────────────────────────────────

    data class SellResult(val error: String? = null, val soldIds: List<String> = emptyList())

    fun sell(
        productId: String,
        variantId: String,
        quantity: Int = 1,
        finalPrice: Long? = null,
    ): SellResult {
        if (quantity < 1) return SellResult("اختر قطعة واحدة على الأقل")
        val product = data.products.firstOrNull { it.id == productId && it.isActive }
            ?: return SellResult("القطعة غير موجودة")
        val variant = product.variants.firstOrNull { it.id == variantId }
            ?: return SellResult("اختر المقاس")
        if (quantity > variant.stock) return SellResult("المتوفر ${variant.stock} فقط")

        val settings = data.settings
        val list = priceSyp(product, settings, variant)
        val unit = (finalPrice ?: list).coerceAtLeast(0)
        val cost = costSyp(product)
        val profit = (unit - cost).coerceAtLeast(0)
        fun share(pct: Int) = (profit * pct / 100.0).roundToLong()

        val now = System.currentTimeMillis()
        val newSales = List(quantity) { i ->
            Sale(
                id = UUID.randomUUID().toString(),
                productId = product.id,
                variantId = variant.id,
                productName = product.name,
                category = product.category,
                size = variant.size,
                color = variant.color,
                listPrice = list,
                soldPrice = unit,
                unitCost = cost,
                devShare = share(settings.devPercent),
                goalShare = share(settings.goalsPercent),
                expenseShare = share(settings.expensesPercent),
                soldAt = now + i,
            )
        }

        val totalGoalShare = newSales.sumOf { it.goalShare }
        val goals = applyGoalFill(data.goals, totalGoalShare)

        val updatedVariants = product.variants.map {
            if (it.id == variantId) it.copy(stock = it.stock - quantity) else it
        }
        val updatedProduct = product.copy(variants = updatedVariants)

        commit(
            data.copy(
                products = data.products.map { if (it.id == productId) updatedProduct else it },
                sales = data.sales + newSales,
                goals = goals,
            )
        )
        lastSoldIds = newSales.map { it.id }
        return SellResult(soldIds = lastSoldIds)
    }

    /** يصب مبلغ التصميد على الأهداف بالأولوية */
    private fun applyGoalFill(goals: List<Goal>, amount: Long): List<Goal> {
        if (amount <= 0 || goals.isEmpty()) return goals
        var remaining = amount
        val ordered = goals.sortedBy { it.priority }
        val result = goals.associateBy { it.id }.toMutableMap()
        for (g in ordered) {
            if (remaining <= 0) break
            if (g.isAchieved) continue
            val add = minOf(remaining, g.remaining)
            val filled = g.filled + add
            remaining -= add
            result[g.id] = g.copy(
                filled = filled,
                achievedAt = if (filled >= g.target) System.currentTimeMillis() else g.achievedAt,
            )
        }
        return goals.map { result[it.id] ?: it }
    }

    private fun reverseGoalFill(goals: List<Goal>, amount: Long): List<Goal> {
        if (amount <= 0 || goals.isEmpty()) return goals
        var remaining = amount
        val ordered = goals.sortedByDescending { it.priority }
        val result = goals.associateBy { it.id }.toMutableMap()
        for (g in ordered) {
            if (remaining <= 0) break
            val take = minOf(remaining, g.filled)
            val filled = g.filled - take
            remaining -= take
            result[g.id] = g.copy(
                filled = filled,
                achievedAt = if (filled < g.target) null else g.achievedAt,
            )
        }
        return goals.map { result[it.id] ?: it }
    }

    /** تراجع فوري عن آخر عملية بيع */
    fun undoLastSale(): String? {
        val ids = lastSoldIds.ifEmpty {
            val last = data.sales.lastOrNull { !it.isVoided && it.returnedAt == 0L } ?: return "لا يوجد بيع للتراجع"
            listOf(last.id)
        }
        ids.forEach { voidSale(it) }
        lastSoldIds = emptyList()
        return null
    }

    fun voidSale(saleId: String) {
        val sale = data.sales.firstOrNull { it.id == saleId } ?: return
        if (sale.isVoided) return
        val products = data.products.map { p ->
            if (p.id != sale.productId) p
            else p.copy(variants = p.variants.map { v ->
                if (v.id == sale.variantId) v.copy(stock = v.stock + 1) else v
            })
        }
        val goals = reverseGoalFill(data.goals, sale.goalShare)
        val sales = data.sales.map {
            if (it.id == saleId) it.copy(isVoided = true) else it
        }
        commit(data.copy(products = products, sales = sales, goals = goals))
    }

    fun returnSale(saleId: String) {
        val sale = data.sales.firstOrNull { it.id == saleId } ?: return
        if (sale.isVoided || sale.returnedAt > 0) return
        val products = data.products.map { p ->
            if (p.id != sale.productId) p
            else p.copy(variants = p.variants.map { v ->
                if (v.id == sale.variantId) v.copy(stock = v.stock + 1) else v
            })
        }
        val goals = reverseGoalFill(data.goals, sale.goalShare)
        val sales = data.sales.map {
            if (it.id == saleId) it.copy(returnedAt = System.currentTimeMillis()) else it
        }
        commit(data.copy(products = products, sales = sales, goals = goals))
    }

    fun undoReturn(saleId: String): String? {
        val sale = data.sales.firstOrNull { it.id == saleId } ?: return "غير موجود"
        if (sale.returnedAt == 0L || sale.isVoided) return "ليس مرتجعاً"
        val product = data.products.firstOrNull { it.id == sale.productId } ?: return "القطعة محذوفة"
        val variant = product.variants.firstOrNull { it.id == sale.variantId } ?: return "المقاس غير موجود"
        if (variant.stock < 1) return "لا يوجد مخزون كافٍ لإلغاء الإرجاع"

        val products = data.products.map { p ->
            if (p.id != sale.productId) p
            else p.copy(variants = p.variants.map { v ->
                if (v.id == sale.variantId) v.copy(stock = v.stock - 1) else v
            })
        }
        val goals = applyGoalFill(data.goals, sale.goalShare)
        val sales = data.sales.map {
            if (it.id == saleId) it.copy(returnedAt = 0L) else it
        }
        commit(data.copy(products = products, sales = sales, goals = goals))
        return null
    }

    // ── Restock ──────────────────────────────────

    fun restockVariant(productId: String, variantId: String, qty: Int, unitCost: Long) {
        if (qty < 1) return
        val product = data.products.firstOrNull { it.id == productId } ?: return
        val updatedVariants = product.variants.map {
            if (it.id == variantId) it.copy(stock = it.stock + qty) else it
        }
        val label = product.variants.firstOrNull { it.id == variantId }
            ?.let { listOf(it.size, it.color).filter { s -> s.isNotBlank() }.joinToString(" / ") } ?: ""
        val purchase = Purchase(
            productId = productId,
            productName = product.name,
            label = label,
            quantity = qty,
            unitCost = unitCost,
            totalSyp = unitCost * qty,
            kind = PurchaseKind.RESTOCK,
        )
        commit(
            data.copy(
                products = data.products.map {
                    if (it.id == productId) it.copy(variants = updatedVariants) else it
                },
                purchases = data.purchases + purchase,
            )
        )
    }

    // ── Expenses & Goals ─────────────────────────

    fun addExpense(expense: Expense) {
        commit(data.copy(expenses = data.expenses + expense))
    }

    fun removeExpense(id: String) {
        commit(data.copy(expenses = data.expenses.filter { it.id != id }))
    }

    fun addGoal(goal: Goal) {
        val priority = (data.goals.maxOfOrNull { it.priority } ?: -1) + 1
        commit(data.copy(goals = data.goals + goal.copy(priority = priority)))
    }

    fun updateGoal(goal: Goal) {
        commit(data.copy(goals = data.goals.map { if (it.id == goal.id) goal else it }))
    }

    fun removeGoal(id: String) {
        commit(data.copy(goals = data.goals.filter { it.id != id }))
    }

    fun moveGoalPriority(id: String, up: Boolean) {
        val sorted = data.goals.sortedBy { it.priority }.toMutableList()
        val idx = sorted.indexOfFirst { it.id == id }
        if (idx < 0) return
        val swapWith = if (up) idx - 1 else idx + 1
        if (swapWith !in sorted.indices) return
        val a = sorted[idx]
        val b = sorted[swapWith]
        sorted[idx] = a.copy(priority = b.priority)
        sorted[swapWith] = b.copy(priority = a.priority)
        commit(data.copy(goals = sorted))
    }

    // ── Settings ─────────────────────────────────

    fun updateSettings(settings: Settings) {
        commit(data.copy(settings = settings))
    }

    fun setCashOnHand(amount: Long) {
        commit(data.copy(settings = data.settings.copy(cashOnHand = amount.coerceAtLeast(0))))
    }

    fun setCategories(categories: List<String>) {
        commit(data.copy(categories = categories.distinct().filter { it.isNotBlank() }))
    }

    /** تصفير الأرباح دون المساس بالمخزون */
    fun resetProfits() {
        commit(
            data.copy(
                sales = emptyList(),
                expenses = emptyList(),
                goals = data.goals.map { it.copy(filled = 0L, achievedAt = null) },
                settings = data.settings.copy(cashOnHand = 0L),
            )
        )
        lastSoldIds = emptyList()
    }

    // ── Stocktake ────────────────────────────────

    fun startStocktake(): String {
        val id = UUID.randomUUID().toString()
        commit(data.copy(stocktakes = data.stocktakes + Stocktake(id = id)))
        return id
    }

    fun updateStocktakeCount(stocktakeId: String, variantId: String, counted: Int) {
        commit(data.copy(stocktakes = data.stocktakes.map { st ->
            if (st.id != stocktakeId) st
            else st.copy(counted = st.counted + (variantId to counted.coerceAtLeast(0)))
        }))
    }

    fun finishStocktake(stocktakeId: String, adjustStock: Boolean) {
        val st = data.stocktakes.firstOrNull { it.id == stocktakeId } ?: return
        val lines = mutableListOf<CountLine>()
        var products = data.products
        for (p in data.products.filter { it.isActive }) {
            for (v in p.variants) {
                val counted = st.counted[v.id] ?: 0
                lines += CountLine(
                    productId = p.id,
                    variantId = v.id,
                    name = p.name,
                    label = listOf(v.size, v.color).filter { it.isNotBlank() }.joinToString(" / "),
                    expected = v.stock,
                    counted = counted,
                    unitCost = costSyp(p),
                )
                if (adjustStock && counted != v.stock) {
                    products = products.map { prod ->
                        if (prod.id != p.id) prod
                        else prod.copy(variants = prod.variants.map { vv ->
                            if (vv.id == v.id) vv.copy(stock = counted) else vv
                        })
                    }
                }
            }
        }
        val finished = st.copy(
            finishedAt = System.currentTimeMillis(),
            lines = lines,
            wasAdjusted = adjustStock,
        )
        commit(
            data.copy(
                products = products,
                stocktakes = data.stocktakes.map { if (it.id == stocktakeId) finished else it },
            )
        )
    }

    // ── Backup ───────────────────────────────────

    fun exportBackup(): File {
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        val file = File(backupDir, "rizqi-backup-$stamp.json")
        file.writeText(StallJson.toJson(data).toString(2), Charsets.UTF_8)
        commit(data.copy(settings = data.settings.copy(lastBackupAt = System.currentTimeMillis())))
        return file
    }

    fun restoreBackup(file: File): String? {
        return try {
            val parsed = StallJson.fromJson(JSONObject(file.readText(Charsets.UTF_8)))
            commit(parsed)
            lastSoldIds = emptyList()
            null
        } catch (e: Exception) {
            "تعذرت الاستعادة: ${e.message}"
        }
    }

    fun listBackups(): List<File> =
        backupDir.listFiles()?.filter { it.extension == "json" }?.sortedByDescending { it.lastModified() }
            ?: emptyList()

    fun imagesDirectory(): File = imagesDir

    fun saveProductImage(sourceUri: android.net.Uri): String? {
        return try {
            val name = "${java.util.UUID.randomUUID()}.jpg"
            val dest = File(imagesDir, name)
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                dest.outputStream().use { output -> input.copyTo(output) }
            } ?: return null
            name
        } catch (e: Exception) {
            null
        }
    }

    fun cleanupOrphanImages() {
        val used = data.products.map { it.imagePath }.filter { it.isNotBlank() }.toSet()
        imagesDir.listFiles()?.forEach { f ->
            if (f.name !in used) f.delete()
        }
    }
}


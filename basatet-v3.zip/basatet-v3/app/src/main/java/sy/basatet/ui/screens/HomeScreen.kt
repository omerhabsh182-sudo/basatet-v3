package sy.basatet.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import sy.basatet.data.APP_NAME
import sy.basatet.data.StallRepository
import sy.basatet.domain.fmtMoney
import sy.basatet.domain.fmtNum
import sy.basatet.domain.isThursday
import sy.basatet.domain.shareBalances
import sy.basatet.domain.startOfDay
import sy.basatet.domain.summarize

@Composable
fun HomeScreen(repository: StallRepository, onOpenStocktake: () -> Unit = {}) {
    val data = repository.data
    val today = summarize(data, startOfDay())
    val balances = shareBalances(data)
    val s = data.settings

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(APP_NAME, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("مدير بسطتك الشخصي", color = MaterialTheme.colorScheme.onSurfaceVariant)

        if (s.showTodayStats) {
            Card(Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(1.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("اليوم", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("المبيعات"); Text(fmtMoney(today.revenue), fontWeight = FontWeight.Medium)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("الربح"); Text(fmtMoney(today.gross), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                    Text("${fmtNum(today.pieces.toLong())} قطعة", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        Card(Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(1.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("تقسيم الأرباح", style = MaterialTheme.typography.titleMedium)
                BalanceLine("التطوير", balances.devBalance)
                BalanceLine(s.savingName, balances.goalAllocated - balances.goalFilled)
                BalanceLine("المصروف الشخصي", balances.expBalance)
            }
        }

        if (isThursday()) {
            Button(onClick = onOpenStocktake, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                Text("جرد المخزون (الخميس)")
            }
        }
    }
}

@Composable
private fun BalanceLine(label: String, amount: Long) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label)
        Text(
            fmtMoney(amount),
            fontWeight = FontWeight.SemiBold,
            color = if (amount < 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
        )
    }
}

package sy.basatet.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import sy.basatet.data.StallRepository
import sy.basatet.domain.fmtMoney
import sy.basatet.domain.fmtNum
import sy.basatet.domain.startOfDay
import sy.basatet.domain.summarize

@Composable
fun HomeScreen(repository: StallRepository) {
    val data = repository.data
    val today = summarize(data, startOfDay())
    val allTime = summarize(data)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            text = "بسطتي",
            style = MaterialTheme.typography.displayLarge,
            fontWeight = FontWeight.Bold,
        )
        Text(
            text = "ملخص اليوم",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            StatCard(
                title = "مبيعات اليوم",
                value = fmtMoney(today.revenue),
                subtitle = "${fmtNum(today.pieces.toLong())} قطعة",
                modifier = Modifier.weight(1f),
            )
            StatCard(
                title = "ربح اليوم",
                value = fmtMoney(today.gross),
                subtitle = "بعد التكلفة",
                modifier = Modifier.weight(1f),
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            StatCard(
                title = "إجمالي المبيعات",
                value = fmtMoney(allTime.revenue),
                subtitle = "${fmtNum(allTime.pieces.toLong())} قطعة",
                modifier = Modifier.weight(1f),
            )
            StatCard(
                title = "المخزون النشط",
                value = fmtNum(data.products.filter { it.isActive }.sumOf { it.totalStock }.toLong()),
                subtitle = "${data.products.count { it.isActive }} منتج",
                modifier = Modifier.weight(1f),
            )
        }

        Spacer(Modifier.height(8.dp))

        Text(
            text = "تقسيم أرباح اليوم",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ShareRow("تطوير البسطة", today.devShare, data.settings.devPercent)
                ShareRow("الأهداف", today.goalShare, data.settings.goalsPercent)
                ShareRow("مصروف شخصي", today.expenseShare, data.settings.expensesPercent)
            }
        }
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    subtitle: String,
    modifier: Modifier = Modifier,
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun ShareRow(label: String, amount: Long, percent: Int) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("$label ($percent%)", style = MaterialTheme.typography.bodyMedium)
        Text(fmtMoney(amount), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
    }
}

package sy.basatet.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// ── Brand palette ────────────────────────────

val AuroraPrimary = Color(0xFF5B8DEF)
val AuroraOnPrimary = Color(0xFFFFFFFF)
val AuroraSecondary = Color(0xFF7C5CFC)
val AuroraTertiary = Color(0xFF00C2A8)
val AuroraBackground = Color(0xFFF7F8FC)
val AuroraSurface = Color(0xFFFFFFFF)
val AuroraError = Color(0xFFE53935)

val NightPrimary = Color(0xFF8AB4F8)
val NightBackground = Color(0xFF0F1117)
val NightSurface = Color(0xFF1A1D27)

private val LightColors = lightColorScheme(
    primary = AuroraPrimary,
    onPrimary = AuroraOnPrimary,
    secondary = AuroraSecondary,
    tertiary = AuroraTertiary,
    background = AuroraBackground,
    surface = AuroraSurface,
    error = AuroraError,
)

private val DarkColors = darkColorScheme(
    primary = NightPrimary,
    onPrimary = Color(0xFF0D1B2A),
    secondary = Color(0xFFB39DFF),
    tertiary = Color(0xFF4DDBCB),
    background = NightBackground,
    surface = NightSurface,
    error = Color(0xFFFF8A80),
)

@Composable
fun BasatetTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = BasatetTypography,
        content = content,
    )
}

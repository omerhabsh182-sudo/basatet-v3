package sy.basatet.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import sy.basatet.data.Expense
import sy.basatet.data.ExpenseBucket
import sy.basatet.data.Goal
import sy.basatet.data.StallRepository
import sy.basatet.domain.bestDay
import sy.basatet.domain.bestHour
import sy.basatet.domain.fmtMoney
import sy.basatet.domain.fmtNum
import sy.basatet.domain.parseDigits
import sy.basatet.domain.shareBalances
import sy.basatet.domain.startOfDay
import sy.basatet.domain.startOfWeek
import sy.basatet.domain.summarize
import sy.basatet.domain.topProducts

@Composable
fun ProfitScreen(repository: StallRepository) {
    val data = repository.data
    val today = summarize(data, startOfDay())
    val week = summarize(data, startOfWeek())
    val all = summarize(data)
    val balances = shareBalances(data)
    val s = data.settings
    var cashInput by remember(s.cashOnHand) { mutableStateOf(if (s.cashOnHand > 0) s.cashOnHand.toString() else "") }
    var goalName by remember { mutableStateOf("") }
    var goalTarget by remember { mutableStateOf("") }
    var expTitle by remember { mutableStateOf("") }
    var expAmount by remember { mutableStateOf("") }
    var expBucket by remember { mutableStateOf(ExpenseBucket.PERSONAL) }

    val live = data.sales.filter { !it.isVoided && it.returnedAt == 0L }
    val top = topProducts(live)
    val day = bestDay(live)
    val hour = bestHour(live)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("الأرباح", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        PeriodCard("اليوم", today)
        PeriodCard("هذا الأسبوع", week)
        PeriodCard("الكل", all)

        // التطوير
        Card(Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(1.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("التطوير", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text("مخصص من الأرباح: ${fmtMoney(balances.devAllocated)}")
                Text("مصروف تطوير: ${fmtMoney(balances.devSpent)}")
                Text("رصيد التطوير: ${fmtMoney(balances.devBalance)}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                OutlinedTextField(
                    value = cashInput,
                    onValueChange = { cashInput = it },
                    label = { Text("المبلغ في المحفظة (نقداً)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                TextButton(onClick = { repository.setCashOnHand(parseDigits(cashInput)) }) {
                    Text("حفظ المحفظة")
                }
                if (s.cashOnHand > 0) {
                    Text("رأس المال مع التطوير ≈ ${fmtMoney(s.cashOnHand + balances.devBalance)}")
                }
            }
        }

        // التصميد
        Card(Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(1.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(s.savingName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text("إجمالي المخصص: ${fmtMoney(balances.goalAllocated)}")
                data.goals.sortedBy { it.priority }.forEach { g ->
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(g.name, fontWeight = FontWeight.Medium)
                            Text("${fmtMoney(g.filled)} / ${fmtMoney(g.target)}")
                        }
                        LinearProgressIndicator(progress = { g.progress }, modifier = Modifier.fillMaxWidth())
                        Row {
                            TextButton(onClick = { repository.moveGoalPriority(g.id, true) }) { Text("↑") }
                            TextButton(onClick = { repository.moveGoalPriority(g.id, false) }) { Text("↓") }
                            TextButton(onClick = { repository.removeGoal(g.id) }) { Text("حذف") }
                        }
                    }
                    HorizontalDivider()
                }
                OutlinedTextField(goalName, { goalName = it }, label = { Text("اسم الهدف") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(goalTarget, { goalTarget = it }, label = { Text("المبلغ المستهدف") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(onClick = {
                    val t = parseDigits(goalTarget)
                    if (goalName.isNotBlank() && t > 0) {
                        repository.addGoal(Goal(name = goalName.trim(), target = t))
                        goalName = ""; goalTarget = ""
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("إضافة هدف") }
            }
        }

        // المصروف الشخصي
        Card(Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(1.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("المصروف الشخصي", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(
                    "الرصيد: ${fmtMoney(balances.expBalance)}",
                    fontWeight = FontWeight.Bold,
                    color = if (balances.expBalance < 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                )
                if (balances.expBalance < 0) {
                    Text("أخذت أكثر من حقك — سيُعوَّض من الأرباح القادمة", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
                OutlinedTextField(expTitle, { expTitle = it }, label = { Text("بيان") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(expAmount, { expAmount = it }, label = { Text("المبلغ") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = expBucket == ExpenseBucket.PERSONAL, onClick = { expBucket = ExpenseBucket.PERSONAL }, label = { Text("شخصي") })
                    FilterChip(selected = expBucket == ExpenseBucket.DEVELOPMENT, onClick = { expBucket = ExpenseBucket.DEVELOPMENT }, label = { Text("تطوير") })
                }
                Button(onClick = {
                    val a = parseDigits(expAmount)
                    if (a > 0) {
                        repository.addExpense(Expense(title = expTitle.ifBlank { "مصروف" }, amount = a, bucket = expBucket))
                        expTitle = ""; expAmount = ""
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("تسجيل مصروف") }
            }
        }

        // تحليل
        Card(Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(1.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("تحليل", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                day?.let { Text("أفضل يوم: ${it.label} — ${fmtMoney(it.profit)}") }
                hour?.let { Text("أفضل ساعة: ${it.label} — ${fmtNum(it.pieces.toLong())} قطعة") }
                if (top.isNotEmpty()) {
                    Text("الأكثر مبيعاً:", fontWeight = FontWeight.Medium)
                    top.take(5).forEach {
                        Text("• ${it.name}: ${it.pieces} قطعة — ربح ${fmtMoney(it.profit)}")
                    }
                }
            }
        }
    }
}

@Composable
private fun PeriodCard(title: String, summary: sy.basatet.domain.PeriodSummary) {
    Card(Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(1.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("المبيعات"); Text(fmtMoney(summary.revenue))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("الربح"); Text(fmtMoney(summary.gross), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
            Text("${fmtNum(summary.pieces.toLong())} قطعة", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

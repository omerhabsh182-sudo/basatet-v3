package sy.basatet.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import sy.basatet.data.StallRepository
import sy.basatet.domain.fmtMoney
import sy.basatet.domain.fmtNum
import sy.basatet.domain.shareBalances
import sy.basatet.domain.startOfDay
import sy.basatet.domain.startOfWeek
import sy.basatet.domain.summarize

@Composable
fun ProfitScreen(repository: StallRepository) {
    val data = repository.data
    val today = summarize(data, startOfDay())
    val week = summarize(data, startOfWeek())
    val all = summarize(data)
    val balances = shareBalances(data)

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("الأرباح", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        PeriodCard("اليوم", today)
        PeriodCard("هذا الأسبوع", week)
        PeriodCard("الكل", all)

        Spacer(Modifier.height(4.dp))
        Text("أرصدة التقسيم", style = MaterialTheme.typography.titleMedium)

        Card(Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(1.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                BalanceRow("تطوير البسطة", balances.devAllocated, balances.devSpent, balances.devBalance)
                HorizontalDivider()
                BalanceRow("مصروف شخصي", balances.expAllocated, balances.expSpent, balances.expBalance)
            }
        }
    }
}

@Composable
private fun PeriodCard(title: String, summary: sy.basatet.domain.PeriodSummary) {
    Card(Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(1.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("المبيعات")
                Text(fmtMoney(summary.revenue), fontWeight = FontWeight.Medium)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("التكلفة")
                Text(fmtMoney(summary.cogs))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("الربح الإجمالي")
                Text(fmtMoney(summary.gross), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
            Text("${fmtNum(summary.pieces.toLong())} قطعة", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun BalanceRow(label: String, allocated: Long, spent: Long, balance: Long) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("مخصص: ${fmtMoney(allocated)}", style = MaterialTheme.typography.bodyMedium)
            Text("مصروف: ${fmtMoney(spent)}", style = MaterialTheme.typography.bodyMedium)
        }
        Text(
            "الرصيد: ${fmtMoney(balance)}",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = if (balance >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
        )
    }
}
